
Traveler — Guarantee 'stays:add' Exists
---------------------------------------
This patch ensures that `{% url 'stays:add' %}` resolves by:
  1) Making sure stays/urls.py defines `name="add"`.
  2) If no suitable create view exists, injecting a safe minimal create view
     (ModelForm over stays.models.Stay with fields='__all__') and a template.

What it does (idempotent):
  - Adds/keeps: app_name = "stays"
  - Ensures: path("add/", views.stay_add, name="add")
  - If views.stay_add (or similar) is missing, it defines one.
  - Creates stays/templates/stays/stay_form.html if missing.
  - Redirects to stays:detail if it exists, else stays:list.

How to run:
  1) Copy `patch_add_route_fix.py` into your project root (same folder as manage.py).
  2) Run: venv\Scripts\python.exe patch_add_route_fix.py
  3) Run server: venv\Scripts\python.exe manage.py runserver

Safe: backs up any modified file with a timestamped .bak.
