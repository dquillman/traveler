
Traveler Django Namespace & Template Encoding Fix
------------------------------------------------
What this does
1) Ensures the 'stays' app has a URL namespace:
   - creates/updates stays/urls.py with `app_name = "stays"`
   - adds named routes: list, add, detail, edit (using views.stay_* functions)
2) Ensures project config/urls.py includes the 'stays' URLs with a namespace.
   - Adds: path("stays/", include(("stays.urls", "stays"), namespace="stays"))
   - Ensures `include` is imported.
3) Cleans UTF-8 BOMs and stray replacement characters in templates (*.html).
   - Removes leading BOM U+FEFF
   - Removes U+FFFD "�" replacement chars

How to use (Windows, in your venv):
-----------------------------------
1) Copy BOTH files into your project root folder (the one with manage.py), e.g.:
     G:\users\daveq\traveler\
   Files:
     - patch_namespace_fix.py
     - patch_namespace_fix.ps1   (optional helper to run the Python script)

2) Run it (choose one):
   PowerShell (run from project root):
     .\patch_namespace_fix.ps1
   OR Python directly:
     venv\Scripts\python.exe patch_namespace_fix.py

3) Restart your dev server:
     venv\Scripts\python.exe manage.py runserver

The script is idempotent: run it again safely if needed.

Notes:
- It will back up any modified file next to it with a .bak timestamp.
- If stays/urls.py doesn't exist, it will be created with standard routes.
- If your view names differ, adjust stays/urls.py after generation.

Troubleshooting:
- If you still see NoReverseMatch, open config/urls.py and confirm there is EXACTLY:
     path("stays/", include(("stays.urls", "stays"), namespace="stays")),
  and stays/urls.py contains `app_name = "stays"` and routes named 'add', 'detail', 'edit', 'list'.
