
Patch — Fix Reverse for 'list' not found
----------------------------------------
Ensures the named route 'stays:list' exists.

What it does:
  1) stays/urls.py → adds: path('', views.stay_list, name='list')
  2) stays/views.py → if `stay_list` doesn't exist, creates a thin alias to an existing list/index view
     or a minimal implementation that renders 'stays/stay_list.html'.

Apply:
  1) Copy `patch_fix_list_route.py` to your project root (same dir as manage.py).
  2) Run: venv\Scripts\python.exe patch_fix_list_route.py
  3) Start server.
