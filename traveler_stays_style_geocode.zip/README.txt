
Traveler — Stays page styling + Auto-Geocode
============================================

WHAT YOU GET
------------
1) Color/UI: Replaces the three stays templates to **extend `base.html`** so they pick up
   the same header/menus/colors as your other pages.
     - stays/templates/stays/stay_list.html
     - stays/templates/stays/stay_detail.html
     - stays/templates/stays/stay_form.html
   (Uses `{% block title %}` and `{% block content %}`.)

2) Auto-Geocode: If a Stay has city/state (and/or address) but missing latitude/longitude,
   they are automatically filled using OpenStreetMap (Nominatim via geopy) on save.
     - stays/utils.py       → `geocode_address()` helper
     - stays/signals.py     → pre_save to auto-fill lat/lng if empty
     - stays/apps.py        → wires signals in `ready()`
     - stays/__init__.py    → (no change required; Django 5 auto-loads AppConfig)

3) Backfill command: Fill coords for existing rows:
     - stays/management/commands/backfill_geocode.py

REQUIREMENTS
------------
- Adds dependency: geopy
    (venv) pip install geopy
- settings.py already has `GEOCODER_USER_AGENT = 'traveler-app'` (good). If not, add it.

INSTALL
-------
1) Unzip this at your project root (same folder as manage.py). It will create/overwrite the
   listed stays/* files only.
2) Install geopy:
     venv\Scripts\pip install geopy
3) Run server:
     venv\Scripts\python.exe manage.py runserver

BACKFILL (optional, to geocode existing rows)
---------------------------------------------
     venv\Scripts\python.exe manage.py backfill_geocode --limit 200
   - You can omit --limit to process all; script sleeps politely to respect Nominatim usage.

HOW IT WORKS
------------
- On add/edit: if latitude/longitude are blank, but we have address/city/state/zipcode,
  we build a query string and geocode.
- Signal sets obj.latitude/obj.longitude if a geocode result is found.
- We skip geocoding when lat/lng already set.

TROUBLESHOOTING
---------------
- If you use a different base template path, edit `{% extends 'base.html' %}` accordingly.
- If your Stay model uses different field names for address pieces, update the
  `build_query_from_stay()` helper in stays/utils.py.
