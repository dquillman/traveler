from django import forms
from .models import Stay

class StayForm(forms.ModelForm):
    class Meta:
        model = Stay
        fields = [
            "photo",
            "park",
            "city",
            "state",
            "check_in",
            "leave",
            "nights",
            "rate_per_night",
            "total",
            "fees",
            "paid",
            "site",
            "rating",
            "elect_extra",
            "latitude",
            "longitude",
        ]
        widgets = {
            "check_in": forms.DateInput(attrs={"type": "date"}),
            "leave": forms.DateInput(attrs={"type": "date"}),
            "paid": forms.CheckboxInput(),
            "elect_extra": forms.CheckboxInput(),
        }
        labels = {
            "rate_per_night": "Rate per night",
            "elect_extra": "Elect extra",
            "check_in": "Check in",
        }
