
Traveler — Map Markers + 3 Charts Bundle (Real Zip)
===================================================

This zip contains:
  • patch_apply_map_charts.py  -> apply script (idempotent)
  • stays/templates/stays/map.html
  • stays/templates/stays/charts.html

How to use
----------
1) Download this zip and extract it into your Django project ROOT (same folder as manage.py).
2) Run the patch:
     venv\Scripts\python.exe patch_apply_map_charts.py
3) Start server:
     venv\Scripts\python.exe manage.py runserver
4) Open:
     http://127.0.0.1:8000/stays/map/
     http://127.0.0.1:8000/stays/charts/
