from django.db import models
from datetime import date

class Stay(models.Model):
    park = models.CharField(max_length=150, blank=True, null=True)
    city = models.CharField(max_length=100, blank=True, null=True)
    state = models.CharField(max_length=2, blank=True, null=True)

    check_in = models.DateField(blank=True, null=True)
    leave = models.DateField(blank=True, null=True)

    # Stored in the DB, auto-updated on save()
    nights = models.IntegerField(blank=True, null=True, editable=False)

    rating = models.IntegerField(blank=True, null=True)
    elect_extra = models.BooleanField(default=False)
    paid = models.BooleanField(default=False)

    latitude = models.FloatField(blank=True, null=True)
    longitude = models.FloatField(blank=True, null=True)

    class Meta:
        ordering = ("check_in", "park", "city")

    def __str__(self):
        bits = [self.park or self.city or "Stay"]
        if self.state:
            bits.append(self.state)
        if self.check_in:
            bits.append(self.check_in.isoformat())
        return " • ".join(bits)

    def save(self, *args, **kwargs):
        # Uppercase state initials, if present
        if self.state:
            self.state = self.state.upper()

        # Compute nights if we have both dates
        n = None
        if self.check_in and self.leave:
            try:
                days = (self.leave - self.check_in).days
                if days < 0:
                    days = 0
                n = days
            except Exception:
                n = None
        self.nights = n

        super().save(*args, **kwargs)
