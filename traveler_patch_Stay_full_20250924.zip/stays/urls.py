from django.urls import path
from . import views

app_name = "stays"

urlpatterns = [
    path("", views.stay_list, name="list"),
    path("add/", views.stay_add, name="add"),
    path("<int:pk>/edit/", views.stay_edit, name="edit"),
    path("<int:pk>/delete/", views.stay_delete, name="delete"),
    path("map-data/", views.stays_map_data, name="map_data"),
    path("charts/", views.stays_charts, name="charts"),
    path("import/", views.stays_import, name="import"),
    path("export/", views.stays_export, name="export"),
    path("appearance/", views.stays_appearance, name="appearance"),
    path("map/", views.stays_map, name="map"),
]
