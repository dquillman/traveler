# -*- coding: utf-8 -*-
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.http import JsonResponse
from django.forms import ModelForm
from .models import Stay

# Try to use the app's StayForm; fallback to a simple ModelForm if missing
try:
    from stays.forms import StayForm as _StayForm
except Exception:
    _StayForm = None

class _FallbackStayForm(ModelForm):
    class Meta:
        model = Stay
        fields = "__all__"

StayForm = _StayForm or _FallbackStayForm


def _apply_stay_filters(qs, request):
    """Apply multi-filters: state, city, rating (if rating field exists)."""
    states = request.GET.getlist("state") or ([request.GET.get("state")] if request.GET.get("state") else [])
    cities = request.GET.getlist("city") or ([request.GET.get("city")] if request.GET.get("city") else [])
    ratings = request.GET.getlist("rating") or ([request.GET.get("rating")] if request.GET.get("rating") else [])

    states = [s for s in states if s]
    cities = [c for c in cities if c]

    ratings_clean = []
    for r in ratings:
        try:
            ratings_clean.append(int(r))
        except Exception:
            pass

    if states:
        qs = qs.filter(state__in=states)
    if cities:
        qs = qs.filter(city__in=cities)

    # Only filter by rating if the field exists
    field_names = {getattr(f, "attname", None) or getattr(f, "name", None) for f in Stay._meta.get_fields()}
    if ratings_clean and "rating" in field_names:
        qs = qs.filter(rating__in=ratings_clean)

    return qs


def stay_list(request):
    qs = Stay.objects.all()
    # Choices are guarded against missing columns
    field_names = {getattr(f, "attname", None) or getattr(f, "name", None) for f in Stay._meta.get_fields()}

    def safe_distinct(col):
        if col not in field_names:
            return []
        return list(
            Stay.objects.values_list(col, flat=True)
            .exclude(**{f"{col}__isnull": True})
            .exclude(**{f"{col}__exact": ""})
            .distinct()
            .order_by(col)
        )

    state_choices = safe_distinct("state")
    city_choices = safe_distinct("city")
    rating_choices = [1, 2, 3, 4, 5]

    qs = _apply_stay_filters(qs, request)

    context = {
        "stays": qs,
        "state_choices": state_choices,
        "city_choices": city_choices,
        "rating_choices": rating_choices,
    }
    return render(request, "stays/stay_list.html", context)


def stay_add(request):
    if request.method == "POST":
        form = StayForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Stay created.")
            return redirect("stays:list")
    else:
        form = StayForm()
    return render(request, "stays/stay_form.html", {"form": form})


def stay_edit(request, pk):
    obj = get_object_or_404(Stay, pk=pk)
    if request.method == "POST":
        form = StayForm(request.POST, instance=obj)
        if form.is_valid():
            form.save()
            messages.success(request, "Stay updated.")
            return redirect("stays:list")
    else:
        form = StayForm(instance=obj)
    return render(request, "stays/stay_form.html", {"form": form, "stay": obj})


def stay_delete(request, pk):
    obj = get_object_or_404(Stay, pk=pk)
    if request.method == "POST":
        obj.delete()
        return redirect("stays:list")
    return render(request, "stays/stay_confirm_delete.html", {"stay": obj})


def stays_map_data(request):
    # Build values() fields dynamically so missing DB columns never explode
    field_names = {getattr(f, "attname", None) or getattr(f, "name", None) for f in Stay._meta.get_fields()}
    wanted = ["id"]
    for col in ["park", "city", "state", "latitude", "longitude", "check_in", "leave", "nights", "rating", "elect_extra", "paid"]:
        if col in field_names:
            wanted.append(col)
    qs = Stay.objects.all()
    stays = list(qs.values(*wanted))
    return JsonResponse({"stays": stays})


# Stub pages so nothing 404s
def stays_charts(request):
    return render(request, "stays/charts.html", {})

def stays_import(request):
    return render(request, "stays/import.html", {})

def stays_export(request):
    return render(request, "stays/export.html", {})

def stays_appearance(request):
    return render(request, "stays/appearance.html", {})

def stays_map(request):
    return render(request, "stays/map.html", {})
