from django.contrib import admin
from .models import Stay

@admin.register(Stay)
class StayAdmin(admin.ModelAdmin):
    list_display = ("park", "city", "state", "check_in", "leave", "nights", "rating", "elect_extra", "paid")
    search_fields = ("park", "city", "state")
    list_filter = ("state", "elect_extra", "paid", "rating")
    ordering = ("check_in", "park", "city")
