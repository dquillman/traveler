from django import forms
from decimal import Decimal
from .models import Stay

class StayForm(forms.ModelForm):
    nights = forms.IntegerField(required=False, label="#Nts")

    class Meta:
        model = Stay
        fields = ["park","city","state","check_in","leave_date","nights","price_night","total","fees","paid","site","notes","photo"]
        widgets = {
            "check_in": forms.DateInput(attrs={"type":"date"}),
            "leave_date": forms.DateInput(attrs={"type":"date"}),
            "notes": forms.Textarea(attrs={"rows":3}),
        }

    def clean(self):
        cleaned = super().clean()
        rate = cleaned.get("price_night") or Decimal("0")
        total = cleaned.get("total")
        ci = cleaned.get("check_in")
        lv = cleaned.get("leave_date")
        if (total in (None, "")) and ci and lv:
            nights = max((lv - ci).days, 0)
            cleaned["total"] = (rate or Decimal("0")) * nights
        return cleaned
