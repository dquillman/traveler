import requests

def geocode_city_state(city: str, state: str):
    if not city and not state:
        return None
    q = ', '.join([p for p in [city, state] if p])
    try:
        resp = requests.get(
            'https://nominatim.openstreetmap.org/search',
            params={'q': q, 'format': 'json', 'limit': 1},
            headers={'User-Agent': 'rv-tracker/1.0 (non-commercial; contact: example@example.com)'}, timeout=6
        )
        resp.raise_for_status()
        data = resp.json()
        if not data:
            return None
        lat = float(data[0]['lat']); lon = float(data[0]['lon'])
        return (lat, lon)
    except Exception:
        return None
