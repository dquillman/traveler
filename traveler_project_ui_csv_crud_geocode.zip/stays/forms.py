from django import forms
from .models import SiteAppearance, Stay

class SiteAppearanceForm(forms.ModelForm):
    class Meta:
        model=SiteAppearance
        fields=['background']
        widgets={'background': forms.ClearableFileInput(attrs={'accept':'image/*'})}
        help_texts={'background':'Upload a large landscape photo. JPEG/PNG recommended.'}

class CSVUploadForm(forms.Form):
    file = forms.FileField(label='CSV file')

class StayForm(forms.ModelForm):
    class Meta:
        model = Stay
        fields = ['name','city','state','latitude','longitude','start_date','end_date','rating','cost_usd','hookups','notes','photo']
