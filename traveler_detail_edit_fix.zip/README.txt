
Traveler — Guarantee 'stays:detail' and 'stays:edit'
---------------------------------------------------
This patch ensures your template links
    {% url 'stays:detail' s.pk %}
    {% url 'stays:edit' s.pk %}
resolve properly by creating or aliasing the required routes and views.

What it does (idempotent):
  - Ensures stays/urls.py defines routes named 'detail' and 'edit'.
  - If missing in stays/views.py, injects minimal `stay_detail` and `stay_edit` views:
      * stay_detail: renders a simple detail page.
      * stay_edit: ModelForm edit with POST save; reuses stay_form.html.
  - Creates stays/templates/stays/stay_detail.html if missing.
  - Reuses/creates stays/templates/stays/stay_form.html (if needed).
  - Backs up any modified files as .bak with timestamps.

How to run:
  1) Copy `patch_detail_edit_fix.py` to your project root (same as manage.py).
  2) Run: venv\Scripts\python.exe patch_detail_edit_fix.py
  3) Start server: venv\Scripts\python.exe manage.py runserver
