
Hotfix — Remove unsupported 'split' filter in stay_form.html
------------------------------------------------------------
Your template used:  |split:" "
Django doesn't ship a 'split' filter by default, causing TemplateSyntaxError.

This patch updates stays/templates/stays/stay_form.html to explicitly exclude fields
using AND comparisons instead of a split filter.

It changes:
    {% if field.name not in "name address city state zipcode latitude longitude"|split:" " %}
to:
    {% if field.name != 'name' and field.name != 'address' and field.name != 'city'
          and field.name != 'state' and field.name != 'zipcode'
          and field.name != 'latitude' and field.name != 'longitude' %}

How to apply:
  1) Copy patch_fix_split_filter.py to your project root (same folder as manage.py).
  2) Run: venv\Scripts\python.exe patch_fix_split_filter.py
  3) Reload your server.
