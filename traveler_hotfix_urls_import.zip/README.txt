
Hotfix — stays/urls.py missing `views` import
---------------------------------------------
This adds (or fixes) the two required imports:
  - from django.urls import path
  - from . import views

How to use:
  1) Copy `hotfix_urls_import.py` to your project root (same folder as manage.py)
  2) Run: venv\Scripts\python.exe hotfix_urls_import.py
  3) Start server: venv\Scripts\python.exe manage.py runserver
