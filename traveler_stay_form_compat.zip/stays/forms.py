from django import forms
from datetime import date
from .models import Stay

# Desired presentation order (will be applied where fields exist)
DESIRED_ORDER = [
    "photo",
    "park",
    "city",
    "state",
    "check_in",
    "leave",
    "nights",  # displayed read-only if model has non-editable nights
    "rate_per_night",
    "total",
    "fees",
    "paid",
    "site",
    "rating",
    "elect_extra",
    "latitude",
    "longitude",
]

# Determine which model fields are available & editable
_model_fields = {f.name: f for f in Stay._meta.get_fields() if getattr(f, "concrete", False) and not getattr(f, "auto_created", False)}
_editable_model_field_names = [name for name, f in _model_fields.items() if getattr(f, "editable", True)]

# Build ordered list for Meta.fields: include only existing, editable fields in desired order first
_ordered_meta_fields = [name for name in DESIRED_ORDER if name in _editable_model_field_names]
_ordered_meta_fields += [name for name in _editable_model_field_names if name not in _ordered_meta_fields]

class StayForm(forms.ModelForm):
    # If the model has a non-editable 'nights' field, expose a read-only version on the form
    if "nights" in _model_fields and not getattr(_model_fields["nights"], "editable", True):
        nights = forms.IntegerField(label="Nights", required=False, disabled=True)

    class Meta:
        model = Stay
        fields = _ordered_meta_fields
        # Safe widgets: only keys that exist will be applied by Django
        widgets = {
            "check_in": forms.DateInput(attrs={"type": "date"}),
            "leave": forms.DateInput(attrs={"type": "date"}),
        }
        labels = {
            "rate_per_night": "Rate per night",
            "elect_extra": "Elect extra",
            "check_in": "Check in",
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        # Compute 'nights' initial if present on form and model has dates
        if "nights" in self.fields:
            nights_val = None

            # Prefer instance values if available
            ci = getattr(self.instance, "check_in", None)
            lv = getattr(self.instance, "leave", None)
            if ci and lv:
                try:
                    nights_val = (lv - ci).days
                except Exception:
                    nights_val = None

            # If not editing existing (or instance missing), try POSTed values
            if nights_val is None and args and isinstance(args[0], (dict,)):
                ci_s = args[0].get("check_in")
                lv_s = args[0].get("leave")
                try:
                    if ci_s and lv_s:
                        ci_d = date.fromisoformat(ci_s)
                        lv_d = date.fromisoformat(lv_s)
                        nights_val = (lv_d - ci_d).days
                except Exception:
                    nights_val = None

            if nights_val is not None:
                self.fields["nights"].initial = nights_val
