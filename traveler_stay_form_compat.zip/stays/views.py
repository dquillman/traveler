from django.shortcuts import render, redirect, get_object_or_404
from .models import Stay
from .forms import StayForm

def stay_add(request):
    if request.method == "POST":
        form = StayForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect("stay_list")
    else:
        form = StayForm()
    return render(request, "stays/stay_form.html", {"form": form})

def stay_edit(request, pk):
    stay = get_object_or_404(Stay, pk=pk)
    if request.method == "POST":
        form = StayForm(request.POST, request.FILES, instance=stay)
        if form.is_valid():
            form.save()
            return redirect("stay_list")
    else:
        form = StayForm(instance=stay)
    return render(request, "stays/stay_form.html", {"form": form, "stay": stay})
