from django.shortcuts import render
from .models import Stay

def stay_list(request):
    stays = Stay.objects.all().order_by('-check_in')
    return render(request, 'stays/stay_list.html', {'stays': stays})
