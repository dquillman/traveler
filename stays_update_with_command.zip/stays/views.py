import json
from django.core.serializers.json import DjangoJSONEncoder
from django.shortcuts import render
from stays.models import Stay

def stays_map(request):
    qs = (Stay.objects
          .filter(latitude__isnull=False, longitude__isnull=False)
          .values("id", "name", "city", "state", "latitude", "longitude"))

    stays = list(qs)
    stays_json = json.dumps(stays, cls=DjangoJSONEncoder)
    print(f"[stays_map] stays with coords: {len(stays)}")
    return render(request, "stays/map.html", {"stays_json": stays_json})
