from django.contrib import admin
from django.urls import path
from django.conf import settings
from django.conf.urls.static import static
from stays import views

urlpatterns = [
    path("admin/", admin.site.urls),
    path("", views.stay_list, name="stay_list"),
    path("stay/<int:pk>/", views.stay_detail, name="stay_detail"),
    path("map/", views.stay_map, name="stay_map"),
    path("charts/", views.stay_charts, name="stay_charts"),
    path("appearance/", views.appearance_edit, name="appearance_edit"),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
