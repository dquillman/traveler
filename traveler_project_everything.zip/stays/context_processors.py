from .models import SiteAppearance

def site_appearance(request):
    bg_url = None
    try:
        ap = SiteAppearance.objects.first()
        if ap and ap.background:
            bg_url = ap.background.url
    except Exception:
        pass
    return {"BACKGROUND_URL": bg_url}
