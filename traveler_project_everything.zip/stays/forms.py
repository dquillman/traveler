from django import forms
from .models import SiteAppearance

class SiteAppearanceForm(forms.ModelForm):
    class Meta:
        model = SiteAppearance
        fields = ["background"]
        widgets = {"background": forms.ClearableFileInput(attrs={"accept": "image/*"})}
        help_texts = {"background": "Upload a large landscape photo. JPEG/PNG recommended."}
