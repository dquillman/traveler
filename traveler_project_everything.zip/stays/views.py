from collections import defaultdict, Counter
from datetime import date, timedelta
from django.shortcuts import render, get_object_or_404, redirect
from django.utils.timezone import now
from django.contrib.auth.decorators import login_required

from .models import Stay, SiteAppearance
from .forms import SiteAppearanceForm

# -------- Basic pages --------
def stay_list(request):
    stays = Stay.objects.all()
    return render(request, "stays/list.html", {"stays": stays})

def stay_detail(request, pk):
    stay = get_object_or_404(Stay, pk=pk)
    return render(request, "stays/detail.html", {"stay": stay})

# -------- Map --------
def stay_map(request):
    qs = Stay.objects.exclude(latitude__isnull=True).exclude(longitude__isnull=True)
    data = [{
        "id": s.id, "name": s.name, "city": s.city, "state": s.state,
        "lat": s.latitude, "lng": s.longitude,
        "start_date": s.start_date.isoformat(), "end_date": s.end_date.isoformat(),
        "rating": s.rating,
    } for s in qs]
    return render(request, "stays/map.html", {"stays_json": data})

# -------- Charts --------
def _daterange(start: date, end: date):
    cur = start
    while cur <= end:
        yield cur
        cur += timedelta(days=1)

def stay_charts(request):
    stays = list(Stay.objects.all())

    # Nights by month (last ~12 months)
    today = now().date()
    start_12 = (today.replace(day=1) - timedelta(days=365)).replace(day=1)
    nights_by_month = Counter()
    for s in stays:
        if not (s.start_date and s.end_date):
            continue
        for d in _daterange(s.start_date, s.end_date):
            if start_12 <= d <= today:
                nights_by_month[d.strftime("%Y-%m")] += 1
    months_sorted = sorted(nights_by_month.keys())
    nights_month_labels = months_sorted
    nights_month_values = [nights_by_month[m] for m in months_sorted]

    # Nights by state
    nights_by_state = Counter()
    for s in stays:
        if s.state and s.start_date and s.end_date:
            nights_by_state[s.state.strip()] += (s.end_date - s.start_date).days + 1
    state_labels = sorted(nights_by_state.keys(), key=lambda k: -nights_by_state[k])[:12]
    state_values = [nights_by_state[k] for k in state_labels]

    # Avg nightly cost per month
    cost_days_by_month = defaultdict(lambda: {"cost": 0.0, "nights": 0})
    for s in stays:
        if s.start_date and s.end_date and s.cost_usd is not None:
            nights = (s.end_date - s.start_date).days + 1
            if nights <= 0: continue
            ym = s.start_date.strftime("%Y-%m")
            cost_days_by_month[ym]["cost"] += float(s.cost_usd)
            cost_days_by_month[ym]["nights"] += nights
    cost_months = sorted(cost_days_by_month.keys())
    avg_cost_values = [
        round(cost_days_by_month[m]["cost"] / cost_days_by_month[m]["nights"], 2)
        if cost_days_by_month[m]["nights"] else 0.0
        for m in cost_months
    ]

    # Ratings distribution
    ratings = [s.rating for s in stays if s.rating is not None]
    rating_bins = [1,2,3,4,5]
    rating_counts = [ratings.count(r) for r in rating_bins]

    ctx = {
        "nights_month_labels": nights_month_labels,
        "nights_month_values": nights_month_values,
        "state_labels": state_labels,
        "state_values": state_values,
        "cost_months": cost_months,
        "avg_cost_values": avg_cost_values,
        "rating_bins": rating_bins,
        "rating_counts": rating_counts,
    }
    return render(request, "stays/charts.html", ctx)

# -------- Appearance (background upload) --------
@login_required
def appearance_edit(request):
    obj = SiteAppearance.objects.first() or SiteAppearance.objects.create()
    if request.method == "POST":
        form = SiteAppearanceForm(request.POST, request.FILES, instance=obj)
        if form.is_valid():
            form.save()
            return redirect("appearance_edit")
    else:
        form = SiteAppearanceForm(instance=obj)
    return render(request, "stays/appearance.html", {"form": form, "obj": obj})
