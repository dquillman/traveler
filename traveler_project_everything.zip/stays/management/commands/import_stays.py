import csv
from datetime import datetime
from decimal import Decimal, InvalidOperation
from django.core.management.base import BaseCommand, CommandError
from stays.models import Stay

DATE_FORMATS = ["%Y-%m-%d", "%m/%d/%Y", "%d-%m-%Y"]

def parse_date(s, field, rownum):
    if not s:
        raise ValueError(f"[row {rownum}] Missing required date: {field}")
    s = s.strip()
    for fmt in DATE_FORMATS:
        try:
            return datetime.strptime(s, fmt).date()
        except ValueError:
            continue
    raise ValueError(f"[row {rownum}] Could not parse {field}='{s}'. Accepted: {', '.join(DATE_FORMATS)}")

def parse_float(s):
    if s is None or str(s).strip() == "": return None
    return float(s)

def parse_int(s):
    if s is None or str(s).strip() == "": return None
    return int(s)

def parse_decimal(s, rownum, field):
    if s is None or str(s).strip() == "": return None
    try: return Decimal(str(s))
    except InvalidOperation:
        raise ValueError(f"[row {rownum}] Invalid decimal for {field}='{s}'")

class Command(BaseCommand):
    help = "Import RV stays from a CSV file into the Stay model."

    def add_arguments(self, parser):
        parser.add_argument("csv_path", type=str, help="Path to CSV file")
        parser.add_argument("--dry-run", action="store_true", help="Validate only; no writes.")
        parser.add_argument("--encoding", default="utf-8-sig", help="CSV encoding (default utf-8-sig).")
        parser.add_argument("--delimiter", default=",", help="CSV delimiter (default ',').")
        parser.add_argument("--update", action="store_true", help="If (name + start_date) exists, update instead of skipping.")

    def handle(self, *args, **opts):
        path = opts["csv_path"]; dry_run = opts["dry_run"]
        enc = opts["encoding"]; delim = opts["delimiter"]; do_update = opts["update"]

        created = updated = skipped = errors = 0
        try:
            with open(path, "r", encoding=enc, newline="") as f:
                reader = csv.DictReader(f, delimiter=delim)
                if not reader.fieldnames:
                    raise CommandError("CSV appears to have no header row.")
                missing = [c for c in ["name","start_date","end_date"] if c not in reader.fieldnames]
                if missing:
                    raise CommandError(f"CSV missing required columns: {', '.join(missing)}")
                self.stdout.write(self.style.NOTICE(f"Headers: {', '.join(reader.fieldnames)}"))

                for idx, row in enumerate(reader, start=2):
                    try:
                        name = (row.get("name") or "").strip()
                        if not name: raise ValueError(f"[row {idx}] Missing required field: name")
                        start_date = parse_date(row.get("start_date"), "start_date", idx)
                        end_date = parse_date(row.get("end_date"), "end_date", idx)

                        city = (row.get("city") or "").strip()
                        state = (row.get("state") or "").strip()
                        lat = parse_float(row.get("latitude"))
                        lng = parse_float(row.get("longitude"))
                        rating = parse_int(row.get("rating"))
                        cost = parse_decimal(row.get("cost_usd"), idx, "cost_usd")
                        hookups = (row.get("hookups") or "").strip()
                        notes = (row.get("notes") or "").strip()

                        qs = Stay.objects.filter(name=name, start_date=start_date)
                        if qs.exists():
                            if do_update:
                                obj = qs.first()
                                obj.city = city; obj.state = state
                                obj.latitude = lat; obj.longitude = lng
                                obj.end_date = end_date; obj.rating = rating
                                obj.cost_usd = cost; obj.hookups = hookups; obj.notes = notes
                                if not dry_run: obj.save()
                                updated += 1; action = "update"
                            else:
                                skipped += 1; action = "skip (duplicate)"
                        else:
                            obj = Stay(
                                name=name, city=city, state=state,
                                latitude=lat, longitude=lng,
                                start_date=start_date, end_date=end_date,
                                rating=rating, cost_usd=cost, hookups=hookups, notes=notes
                            )
                            if not dry_run: obj.save()
                            created += 1; action = "create"

                        self.stdout.write(f"[row {idx}] {action}: {name} ({start_date} → {end_date})")

                    except Exception as e:
                        errors += 1
                        self.stderr.write(self.style.WARNING(str(e)))
                        continue

        except FileNotFoundError:
            raise CommandError(f"File not found: {path}")

        summary = f"Done. created={created}, updated={updated}, skipped={skipped}, errors={errors}"
        if dry_run: summary += " (dry-run; no DB writes)"
        self.stdout.write(self.style.SUCCESS(summary))
