\
# Traveler bootstrap for Windows PowerShell
$ErrorActionPreference = "Stop"

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $scriptDir

Write-Host "Checking Python..." -ForegroundColor Cyan
$py = Get-Command python -ErrorAction SilentlyContinue
if (-not $py) { Write-Host "Python not found on PATH." -ForegroundColor Red; exit 1 }

if (-not (Test-Path ".\venv")) {
  Write-Host "Creating virtual environment..." -ForegroundColor Cyan
  python -m venv venv
}

$venvActivate = ".\venv\Scripts\Activate.ps1"
if (-not (Test-Path $venvActivate)) { Write-Host "Missing venv activation script." -ForegroundColor Red; exit 1 }
. $venvActivate

Write-Host "Installing Python packages..." -ForegroundColor Cyan
pip install --upgrade pip
pip install -r requirements.txt

Write-Host "Running migrations..." -ForegroundColor Cyan
python manage.py makemigrations
python manage.py migrate

$create = Read-Host "Create a superuser now? (y/N)"
if ($create -match '^(y|Y)$') { python manage.py createsuperuser }

Write-Host "Starting dev server at http://127.0.0.1:8000 ..." -ForegroundColor Green
python manage.py runserver
