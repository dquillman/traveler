
Traveler URL Resolver Loop Fix
------------------------------
This update extends the previous patch. It detects & removes circular URL includes
(e.g., an app urls.py including config.urls or vice versa) that can cause the resolver
to recurse indefinitely during system checks.

What it does:
1) Normalizes config/urls.py:
   - Ensures a single stays include: path("stays/", include(("stays.urls", "stays"), namespace="stays"))
   - Ensures admin include remains: path("admin/", admin.site.urls)
   - Removes any accidental include of "config.urls" (self-include)
   - De-dupes urlpatterns entries
2) Normalizes stays/urls.py:
   - Ensures app_name = "stays"
   - Ensures it ONLY declares paths; removes any include("config.urls") or include of itself
3) Scans ALL *urls.py files under the project and removes any include("config.urls") lines.
4) Keeps backups with timestamp .bak files.

How to run:
  1) Copy patch_url_loop_fix.py to your project root (same dir as manage.py).
  2) Run:
       venv\Scripts\python.exe patch_url_loop_fix.py
  3) Then run your server again:
       venv\Scripts\python.exe manage.py runserver

Safe to re-run. Review backups if you want to see what changed.
