from django.urls import path
from . import views

app_name = "stays"

urlpatterns = [
    path("", views.stay_list, name="stay_list"),
    path("add/", views.stay_add, name="stay_add"),
    path("<int:pk>/edit/", views.stay_edit, name="stay_edit"),
    path("<int:pk>/delete/", views.stay_delete, name="stay_delete"),
]
