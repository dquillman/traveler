from django import forms
from datetime import date
from .models import Stay

# Fixed presentation order for your preferred fields; only include those that exist & editable
DESIRED_ORDER = [
    "photo",
    "park",
    "city",
    "state",
    "check_in",
    "leave",
    "rate_per_night",
    "total",
    "fees",
    "paid",
    "site",
    "rating",
    "elect_extra",
    "latitude",
    "longitude",
]

_model_fields = {f.name: f for f in Stay._meta.get_fields() if getattr(f, "concrete", False) and not getattr(f, "auto_created", False)}
_editable_model_field_names = [name for name, f in _model_fields.items() if getattr(f, "editable", True)]

_ordered_meta_fields = [name for name in DESIRED_ORDER if name in _editable_model_field_names]
_ordered_meta_fields += [name for name in _editable_model_field_names if name not in _ordered_meta_fields]

class StayForm(forms.ModelForm):
    # If nights exists on model but is non-editable, show it read-only
    if "nights" in _model_fields and not getattr(_model_fields["nights"], "editable", True):
        nights = forms.IntegerField(label="Nights", required=False, disabled=True)

    class Meta:
        model = Stay
        fields = _ordered_meta_fields
        widgets = {
            "check_in": forms.DateInput(attrs={"type": "date"}),
            "leave": forms.DateInput(attrs={"type": "date"}),
        }
        labels = {
            "rate_per_night": "Rate per night",
            "elect_extra": "Elect extra",
            "check_in": "Check in",
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if "nights" in self.fields:
            nights_val = None
            ci = getattr(self.instance, "check_in", None)
            lv = getattr(self.instance, "leave", None)
            if ci and lv:
                try:
                    nights_val = (lv - ci).days
                except Exception:
                    nights_val = None
            if nights_val is None and args and isinstance(args[0], (dict,)):
                ci_s = args[0].get("check_in")
                lv_s = args[0].get("leave")
                try:
                    if ci_s and lv_s:
                        ci_d = date.fromisoformat(ci_s)
                        lv_d = date.fromisoformat(lv_s)
                        nights_val = (lv_d - ci_d).days
                except Exception:
                    nights_val = None
            if nights_val is not None:
                self.fields["nights"].initial = nights_val
