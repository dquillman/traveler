from django import forms
from .models import Stay
from datetime import date

class StayForm(forms.ModelForm):
    # Show nights as a read-only form field (the model field is non-editable)
    nights = forms.IntegerField(label="Nights", required=False, disabled=True)

    class Meta:
        model = Stay
        fields = [
            "photo",
            "park",
            "city",
            "state",
            "check_in",
            "leave",
            # 'nights' is intentionally NOT listed here because it's non-editable on the model
            "rate_per_night",
            "total",
            "fees",
            "paid",
            "site",
            "rating",
            "elect_extra",
            "latitude",
            "longitude",
        ]
        widgets = {
            "check_in": forms.DateInput(attrs={"type": "date"}),
            "leave": forms.DateInput(attrs={"type": "date"}),
            "paid": forms.CheckboxInput(),
            "elect_extra": forms.CheckboxInput(),
        }
        labels = {
            "rate_per_night": "Rate per night",
            "elect_extra": "Elect extra",
            "check_in": "Check in",
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Pre-fill the read-only 'nights' field from instance or from posted dates if present
        nights_val = None

        # If editing existing instance with both dates
        if getattr(self.instance, "pk", None) and getattr(self.instance, "check_in", None) and getattr(self.instance, "leave", None):
            try:
                nights_val = (self.instance.leave - self.instance.check_in).days
            except Exception:
                nights_val = None

        # If creating and request POST includes dates, try to compute
        data = args[0] if args else None
        if nights_val is None and isinstance(data, dict):
            ci = data.get("check_in")
            lv = data.get("leave")
            try:
                if ci and lv:
                    ci_d = date.fromisoformat(ci)
                    lv_d = date.fromisoformat(lv)
                    nights_val = (lv_d - ci_d).days
            except Exception:
                nights_val = None

        if nights_val is not None:
            self.fields["nights"].initial = nights_val
