# ===== Been There: Auto placeholder patch (idempotent) =====
$ErrorActionPreference = "Stop"
function Backup-File($p) { if (Test-Path $p) { $ts=Get-Date -Format "yyyyMMdd-HHmmss"; Copy-Item $p "$p.$ts.bak" -Force } }
function Ensure-Dir($p) { if (-not(Test-Path $p)) { New-Item -ItemType Directory -Path $p | Out-Null } }

if (-not (Test-Path ".\manage.py")) { throw "Run from project root." }

# locate files
$settings = Get-ChildItem -Recurse -Filter "settings.py" | Where-Object { $_.FullName -notmatch '\\venv\\|\.venv\\' } | Select-Object -First 1
$projectUrls = Get-ChildItem -Recurse -Filter "urls.py" | Where-Object { $_.FullName -notmatch '\\venv\\|\.venv\\' -and (Get-Content $_.FullName) -match 'urlpatterns\s*=' } | Select-Object -First 1
if (-not $settings) { throw "settings.py not found." }
if (-not $projectUrls) { throw "project urls.py not found." }

# MEDIA settings
$st = Get-Content $settings.FullName -Raw
if ($st -notmatch 'MEDIA_URL\s*=') {
  Backup-File $settings.FullName
  $block = @"
# --- Auto-added by patch-placeholder.ps1 ---
MEDIA_URL = "/media/"
MEDIA_ROOT = BASE_DIR / "media"
# -------------------------------------------
"@
  $st = $st.TrimEnd() + "`r`n`r`n" + $block
  Set-Content $settings.FullName $st -Encoding UTF8
}

# INSTALLED_APPS app config
$st = Get-Content $settings.FullName -Raw
if ($st -match 'INSTALLED_APPS\s*=\s*\[') {
  if ($st -match "'stays'") {
    Backup-File $settings.FullName
    $st = $st -replace "'stays'","'stays.apps.StaysConfig'"
    Set-Content $settings.FullName $st -Encoding UTF8
  } elseif ($st -notmatch 'stays\.apps\.StaysConfig') {
    Backup-File $settings.FullName
    $st = $st -replace '(INSTALLED_APPS\s*=\s*\[)', "`$1`r`n    'stays.apps.StaysConfig',"
    Set-Content $settings.FullName $st -Encoding UTF8
  }
}

# project urls media/static serve (dev)
$ut = Get-Content $projectUrls.FullName -Raw
$needsStaticImport   = ($ut -notmatch 'from django\.conf\.urls\.static import static')
$needsSettingsImport = ($ut -notmatch 'from django\.conf import settings')
$needsAppend         = ($ut -notmatch 'urlpatterns\s*\+\=\s*static\(settings\.MEDIA_URL')
if ($needsSettingsImport) { $ut = "from django.conf import settings`r`n" + $ut }
if ($needsStaticImport)   { $ut = "from django.conf.urls.static import static`r`n" + $ut }
if ($needsAppend) {
$ut = $ut.TrimEnd() + @"

# --- Auto-added by patch-placeholder.ps1 ---
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
# -------------------------------------------
"@
}
Set-Content $projectUrls.FullName $ut -Encoding UTF8

# stays app files
$stays = Join-Path (Get-Location) "stays"
if (-not (Test-Path $stays)) { throw "stays/ not found." }
$apps = Join-Path $stays "apps.py"
$utilsDir = Join-Path $stays "utils"; Ensure-Dir $utilsDir
$place = Join-Path $utilsDir "placeholders.py"

$appContent = @"
from django.apps import AppConfig

class StaysConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "stays"

    def ready(self):
        try:
            from .utils.placeholders import ensure_placeholder_image
            ensure_placeholder_image()
        except Exception:
            pass
"@
Set-Content $apps $appContent -Encoding UTF8

$placeContent = @"
from pathlib import Path
from django.conf import settings

def ensure_placeholder_image():
    try:
        from PIL import Image, ImageDraw
    except Exception:
        return

    target_dir = Path(settings.MEDIA_ROOT) / "stays_photos"
    target_dir.mkdir(parents=True, exist_ok=True)
    target_path = target_dir / "placeholder.jpg"
    if target_path.exists():
        return

    w, h = 400, 300
    img = Image.new("RGB", (w, h), (210, 210, 210))
    d = ImageDraw.Draw(img)
    text = "No Photo"
    tw = d.textlength(text)
    th = 16
    d.text(((w - tw) / 2, (h - th) / 2), text, fill=(0, 0, 0))
    img.save(target_path, format="JPEG", quality=88)
"@
Set-Content $place $placeContent -Encoding UTF8

# models injection (safe)
$models = Join-Path $stays "models.py"
if (-not (Test-Path $models)) { throw "stays/models.py not found." }
$mt = Get-Content $models -Raw
$changed = $false
if ($mt -notmatch 'from django\.core\.files\.storage import default_storage') {
  $mt = "from django.core.files.storage import default_storage`r`n" + $mt; $changed = $true
}
if ($mt -notmatch 'from django\.conf import settings') {
  $mt = "from django.conf import settings`r`n" + $mt; $changed = $true
}
if ($mt -notmatch '@property\s+def\s+photo_url') {
$prop = @"
    @property
    def photo_url(self):
        candidate = self.photo.name if getattr(self, "photo", None) and self.photo and self.photo.name else None
        if candidate:
            try:
                if default_storage.exists(candidate):
                    return settings.MEDIA_URL + candidate
            except Exception:
                pass
        return settings.MEDIA_URL + "stays_photos/placeholder.jpg"
"@
  if ($mt -match 'class\s+Stay\s*\(models\.Model\)\s*:(.*?)(\nclass\s|\Z)') {
    $mt = $mt -replace '(class\s+Stay\s*\(models\.Model\)\s*:\s*[\s\S]*?)(\nclass\s|\Z)', "`${1}`r`n$prop`r`n`$2"
  } else {
    $mt = $mt.TrimEnd() + "`r`n`r`n" + $prop
  }
  $changed = $true
}
if ($changed) { Set-Content $models $mt -Encoding UTF8 }

# media dir
$media = Join-Path (Split-Path $settings.FullName -Parent) "..\media\stays_photos"
try { $media = Resolve-Path $media } catch {}
if (-not (Test-Path $media)) { New-Item -ItemType Directory -Path $media | Out-Null }

Write-Host "Placeholder patch complete."
