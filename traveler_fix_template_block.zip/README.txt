
Patch — Fix 'expected empty or endfor' by simplifying {% if %} block
-------------------------------------------------------------------
This replaces the multi-line IF inside the for-loop in
  stays/templates/stays/stay_form.html
with a single-line condition to avoid parser confusion.

Apply:
  1) Copy patch_fix_template_block.py to your project root (same dir as manage.py).
  2) Run: venv\Scripts\python.exe patch_fix_template_block.py
  3) Reload server.
