from django.contrib import admin
from django.urls import path
from django.conf import settings
from django.conf.urls.static import static
from stays import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.stay_list, name='stay_list'),
    path('stay/<int:pk>/', views.stay_detail, name='stay_detail'),
    path('stays/new/', views.stay_create, name='stay_create'),
    path('stays/<int:pk>/edit/', views.stay_edit, name='stay_edit'),
    path('stays/<int:pk>/delete/', views.stay_delete, name='stay_delete'),
    path('map/', views.stay_map, name='stay_map'),
    path('charts/', views.stay_charts, name='stay_charts'),
    path('appearance/', views.appearance_edit, name='appearance_edit'),
    path('export/', views.export_stays_csv, name='export_stays_csv'),
    path('import/', views.import_stays_csv, name='import_stays_csv'),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
