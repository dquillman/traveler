import csv, io
from collections import defaultdict, Counter
from datetime import date, timedelta
from django.shortcuts import render, get_object_or_404, redirect
from django.utils.timezone import now
from django.contrib import messages
from django.http import HttpResponse
from .models import Stay, SiteAppearance
from .forms import SiteAppearanceForm, CSVUploadForm, StayForm

# -------- Basic pages --------
def stay_list(request):
    stays = Stay.objects.all()
    return render(request, 'stays/list.html', {'stays': stays})

def stay_detail(request, pk):
    stay = get_object_or_404(Stay, pk=pk)
    return render(request, 'stays/detail.html', {'stay': stay})

# -------- Create / Edit / Delete (no admin required) --------
def stay_create(request):
    if request.method == 'POST':
        form = StayForm(request.POST, request.FILES)
        if form.is_valid():
            obj = form.save()
            messages.success(request, 'Stay created.')
            return redirect('stay_detail', pk=obj.pk)
    else:
        form = StayForm()
    return render(request, 'stays/form.html', {'form': form, 'title': 'Add Stay'})

def stay_edit(request, pk):
    obj = get_object_or_404(Stay, pk=pk)
    if request.method == 'POST':
        form = StayForm(request.POST, request.FILES, instance=obj)
        if form.is_valid():
            form.save()
            messages.success(request, 'Stay updated.')
            return redirect('stay_detail', pk=obj.pk)
    else:
        form = StayForm(instance=obj)
    return render(request, 'stays/form.html', {'form': form, 'title': 'Edit Stay'})

def stay_delete(request, pk):
    obj = get_object_or_404(Stay, pk=pk)
    if request.method == 'POST':
        obj.delete()
        messages.success(request, 'Stay deleted.')
        return redirect('stay_list')
    return render(request, 'stays/confirm_delete.html', {'obj': obj})

# -------- Map --------
def stay_map(request):
    qs = Stay.objects.exclude(latitude__isnull=True).exclude(longitude__isnull=True)
    data = [{ 'id': s.id, 'name': s.name, 'city': s.city, 'state': s.state,
              'lat': s.latitude, 'lng': s.longitude,
              'start_date': s.start_date.isoformat(), 'end_date': s.end_date.isoformat(),
              'rating': s.rating } for s in qs]
    return render(request, 'stays/map.html', {'stays_json': data})

# -------- Charts --------
def _daterange(start: date, end: date):
    cur = start
    while cur <= end:
        yield cur
        cur += timedelta(days=1)

def stay_charts(request):
    stays = list(Stay.objects.all())
    today = now().date()
    start_12 = (today.replace(day=1) - timedelta(days=365)).replace(day=1)
    nights_by_month = Counter()
    for s in stays:
        if not (s.start_date and s.end_date): continue
        for d in _daterange(s.start_date, s.end_date):
            if start_12 <= d <= today:
                nights_by_month[d.strftime('%Y-%m')] += 1
    months_sorted = sorted(nights_by_month.keys())
    nights_month_labels = months_sorted
    nights_month_values = [nights_by_month[m] for m in months_sorted]
    nights_by_state = Counter()
    for s in stays:
        if s.state and s.start_date and s.end_date:
            nights_by_state[s.state.strip()] += (s.end_date - s.start_date).days + 1
    state_labels = sorted(nights_by_state.keys(), key=lambda k: -nights_by_state[k])[:12]
    state_values = [nights_by_state[k] for k in state_labels]
    cost_days_by_month = defaultdict(lambda: {'cost':0.0,'nights':0})
    for s in stays:
        if s.start_date and s.end_date and s.cost_usd is not None:
            nights = (s.end_date - s.start_date).days + 1
            if nights <= 0: continue
            ym = s.start_date.strftime('%Y-%m')
            cost_days_by_month[ym]['cost'] += float(s.cost_usd)
            cost_days_by_month[ym]['nights'] += nights
    cost_months = sorted(cost_days_by_month.keys())
    avg_cost_values = [ round(cost_days_by_month[m]['cost']/cost_days_by_month[m]['nights'],2)
                        if cost_days_by_month[m]['nights'] else 0.0 for m in cost_months ]
    ratings = [s.rating for s in stays if s.rating is not None]
    rating_bins = [1,2,3,4,5]
    rating_counts = [ratings.count(r) for r in rating_bins]
    ctx = {'nights_month_labels': nights_month_labels,
           'nights_month_values': nights_month_values,
           'state_labels': state_labels, 'state_values': state_values,
           'cost_months': cost_months, 'avg_cost_values': avg_cost_values,
           'rating_bins': rating_bins, 'rating_counts': rating_counts}
    return render(request, 'stays/charts.html', ctx)

# -------- Appearance (still admin-only if you prefer) --------
def appearance_edit(request):
    obj = SiteAppearance.objects.first() or SiteAppearance.objects.create()
    if request.method == 'POST':
        form = SiteAppearanceForm(request.POST, request.FILES, instance=obj)
        if form.is_valid():
            form.save()
            messages.success(request, 'Background updated.')
            return redirect('appearance_edit')
    else:
        form = SiteAppearanceForm(instance=obj)
    return render(request, 'stays/appearance.html', {'form': form, 'obj': obj})

# -------- Export CSV --------
def export_stays_csv(request):
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="stays.csv"'
    writer = csv.writer(response)
    writer.writerow(['name','city','state','latitude','longitude','start_date','end_date','rating','cost_usd','hookups','notes'])
    for s in Stay.objects.all().order_by('-start_date'):
        writer.writerow([s.name,s.city,s.state,s.latitude,s.longitude,s.start_date,s.end_date,s.rating,s.cost_usd,s.hookups,s.notes])
    return response

# -------- Import CSV (web form) --------
def import_stays_csv(request):
    if request.method == 'POST':
        form = CSVUploadForm(request.POST, request.FILES)
        if form.is_valid():
            file = form.cleaned_data['file']
            decoded = file.read().decode('utf-8-sig')
            reader = csv.DictReader(io.StringIO(decoded))
            count = 0
            for row in reader:
                Stay.objects.create(
                    name=row['name'],
                    city=row.get('city',''),
                    state=row.get('state',''),
                    latitude=row.get('latitude') or None,
                    longitude=row.get('longitude') or None,
                    start_date=row['start_date'],
                    end_date=row['end_date'],
                    rating=row.get('rating') or None,
                    cost_usd=row.get('cost_usd') or None,
                    hookups=row.get('hookups',''),
                    notes=row.get('notes',''),
                )
                count += 1
            messages.success(request, f'Imported {count} stays from CSV.')
            return redirect('stay_list')
    else:
        form = CSVUploadForm()
    return render(request, 'stays/import.html', {'form': form})
