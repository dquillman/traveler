from django.contrib import admin
from .models import Stay, SiteAppearance
@admin.register(Stay)
class StayAdmin(admin.ModelAdmin):
    list_display=('name','city','state','start_date','end_date','rating','cost_usd')
    list_filter=('state','start_date','rating')
    search_fields=('name','city','state','notes')
@admin.register(SiteAppearance)
class SiteAppearanceAdmin(admin.ModelAdmin):
    list_display=('updated_at',)
    def has_add_permission(self, request):
        if SiteAppearance.objects.exists():
            return False
        return super().has_add_permission(request)
