def site_appearance(request):
    return {"SITE_NAME": "Traveler"}
