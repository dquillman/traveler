import csv
print('Use web /import/ now; legacy command placeholder')
